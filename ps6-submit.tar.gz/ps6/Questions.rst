
Questions
=========

Norm
----

* Look through the code for ``run()`` in ``norm_utils.hpp``.  How are we setting the number of threads for OpenMP to use?
The threads used starts at 1 and then increases to a max number set by the user at the command line upon execution.

* Which version of ``norm`` provides the best parallel performance?  How do the results compare to the parallelized versions of ``norm`` from ps5?
The norm versions that are parallelized using reduction to protect the critical race condition variable seem to perform equally well.  norm_block_reduction and surprisingly norm_cyclic_reduction had comparable results.


* Which version of ``norm`` provides the best parallel performance for larger problems (i.e., problems at the top end of the default sizes in the drivers or larger)?  How do the results compare to the parallelized versions of ``norm`` from ps5?
norm_block_reduction was in the group of the highest performers.  And if we compare the norm_block_reduction() in this assignment to the pnorm() in ps5; norm_block_reduction performs better with the smaller matrix sizes (e.g. N = 1048576)
where with 8 threads, i got ~ 15 GFLOPs/sec vs only 4.4 for pnorm() at the same threadnumber count.
On the other hand, although at the largest N size measured of 33554432, pnorm and norm_block_reduction() performed about ~8.3-8.6 GFLOPs/sec, norm_block_reduction performance was on a downward 
trajectory and as the problem size grew larger it was going to get worse.  So it's seems less scalable to larger problems then the manual threading we performmed in PS5 with pnorm().

* Which version of ``norm`` provides the best parallel performance for small problems (i.e., problems smller than the low end of the default sizes in the drivers)?  How do the results compare to the parallelized versions of ``norm`` from ps5?  
The norm versions with the omp critical decoration performed the least well.  But they seemed to perform equally badly regardless of the algorithm (block or cyclic).
Compared to the parallelization of norms (pnorm, cnorm, fnorm), they were much much worse.


Sparse Matrix-Vector Product
----------------------------

* How does ``pmatvec.cpp`` set the number of OpenMP threads to use?
The maximum number of threads to use is defaulted to 8 but can be overriden if an argument is entered (third arg) at the command line during execution.
It will start with 1 thread and then increase by powers of 2, until it reaches the max thread count that is either 8 by default or entered at the command line as explained above. 


* (For discussion on Piazza.)
What characteristics of a matrix would make it more or less likely to exhibit an error 
if improperly parallelized?  Meaning, if, say, you parallelized ``CSCMatrix::matvec`` with just basic  columnwise partitioning -- there would be potential races with the same locations in ``y`` being read and written by multiple threads.  But what characteristics of the matrix give rise to that kind of problem?  Are there ways to maybe work around / fix that if we knew some things in advance about the (sparse) matrix?
I think that any matvec multiplication where the inner loop equation varies based on the outer loop variable (like CSCMatrix:matvec), would create a race condition.  And yes the more threads the more likely they will create an error.
You could resolve this by using the transpose, so the sparse matrix is written against the transpose of the original matrix, and then perform the multiplication so that the inner loop has a constant outer loop value.
so it must look like:   y(i) += storage_[j] * x(row_indices_[j]);  - where i is constant within the inner loop.  Here there is no race condition for the specific y(i) location.  If each inner loop in the 

* Which methods did you parallelize?  What directives did you use?  How much parallel speedup did you see for 1, 2, 4, and 8 threads?
I parallelized CSCMatrix::t_matvec and CSRMatrix::matvec using '#pragma omp parallel for' - adding it prior to the outer loop.  
Since each inner loop writes to a single y(i), where i is constant, location, there shouldn't be a race condition.  And it passed the pmatvec_test.exe test.
For the other matrix vector multiplication functions (CSCMatrix:matvec & CSRMatrix::t_matvec)), I tried using the '#pragma omp parallel for' with 
'#pragma omp critical', and then also tried '#pragma omp parallel reduction(+:t)', along with hoising, but they proved so slow, slower than sequential, that i took  it out.
Performance for CSR and CSC^T without parallelization:
CSR:  1.9-2.6 GFLOPs/sec (going from largest to smallest N grid size)
CSC^T:  1.7-2.7 GFLOPs/sec (going from largest to smallest N grid size)
Performance after parallelization:
1 Thread: Performance range (vs. without parallelization) stayed the same (1.4-3 GFLOPs/sec) but it wasn't based on grid size.  small and large had the worst performnace at 1.4 and the mid size had the best at 3.  Strange.
2 threads  CSR performance almost doubled with range 5.3 - 2.5 (didn't see a smooth increaes from small to large problem size, weird). The best performance of 5.3 GFLOPs/sec was at N Grid 256)
           CSC^t had even better performance, ranging from 2.5-6.3 (highest performance was at N Grid = 256 again)
4 threads:  CSR speed was greater again at 2.5-10.1, again the highest GFLOPs/sec speed at N grid = 256.  But in general the performance seemed to be worse at the largest grid sizes
            CSC^t speed also improved over 2 threads, coming in at 2.5-11.9 GFLOPs.  N grid = 256 seems to be the optimal size, as the performance was best here agin at 11.9
8 Threads:  CSR improvement not significant over 4 threads, ranging from 2.5-11.9
            CSC^t, same as CSR. 
Seems that N = 256 grid size is optimal for this OpenMP parallelization, and that it does not scale well with larger grid sizes (I always saw a drop off to 2.5 GFLOPs at largest grid size with 2,4 and 8 threads)



Sparse Matrix Dense Matrix Product (AMATH583 Only)
--------------------------------------------------


* Which methods did you parallelize?  What directives did you use?  How much parallel speedup did you see for 1, 2, 4, and 8 threads?  How does the parallel speedup compare to sparse matrix by vector product?
I parallelized both CSC and CSR matmat functions.  I thought it would break down for CSC but it passed the test?  not sure if that is just coincidence and it would break wwith other tests.
In both cases i used the '#pragma omp parallel for' directive, with no following critical directive.
I thought this could be working for CSC if  this directive means that only a single thread is spawned for each iteration path of the highest level loop.  In which case, no race condition would apply, but that may not be the case,
and it just happens to work for the matrix used in the test.exe file.
Regarding Speedup,  at 1 thread, there was none, in fact it went down.
For 2 threads, no speed up.  For 4 threads, start to see about 30 % speed up but again, it's most pronounced at N grid = 256. This must be memory hierarchy effect.
And for 8 threads, i see the most significant speed up, where it tops out at 7.6 GFLOPs/sec, which is about 250% increase over no parallelization.  Again, the peak performance was at N Grid = 256. 

PageRank Reprise
----------------

* Describe any changes you made to pagerank.cpp to get parallel speedup.  How much parallel speedup did you get for 1, 2, 4, and 8 threads?
The only change i made was to pagerank.cpp, by chainging the input file transformation from CSR to CSC Matrix.
This means line 72, was changed from CSRMatrix A = read_csrmatrix(input_file), to:  CSCMatrix A = read_cscmatrix(input_file).
Therefore the overloaded mult() function in amath583sparse.cpp, now has the args to utilize the CSCMatrix::t_matvec function, which is parallelized.  I don't think any other changes were required.
The times were in milliseconds, so i'm not sure how significant they are (i used the G_n_pin_pout.mtx, the largest file) 
So going from 1, 2, 4, 8 threads gave me pagerank elapsed times of 35. 19, 13 and 11.  Seems like time elapsed went down but it's so short hard to be convinced.
Possibly i needed a larger file, but that seemed to be one of the larger files provided in the /data folder.

* (EC) Which functions did you parallelize?  How much additional speedup did you achieve?
I parallelized the mult() function in the amath583.cpp file for matrix vector operations.  I ran pagerank, and after running a several times, didn't get much performance increase at any of the thread numbers.

Load Balanced Partitioning with OpenMP (Extra Credit)
-----------------------------------------------------

* Are there any choices for scheduling that make an improvement in the parallel performance (most importantly, scalability) of pagerank?
I added  omp_set_schedule(omp_sched_dynamic, 0) to the main() function in pagerank.cpp and that seemed to give better performance.
I consistently got a pagerank time elapsed of under 9 ms (without it my best time after many iterations was 11).  Otherwise i didn't get much improvement from
any of the other options such as auto, guided or static.

